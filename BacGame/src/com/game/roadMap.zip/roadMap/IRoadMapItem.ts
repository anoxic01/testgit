interface IRoadMapItem 
{
	setData(v:any):void;
	getData():any;
}
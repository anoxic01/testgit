class RoadStringObject 
{
	/**
	 * 大路
	 */
	public bigRoad:string = "";
	/**
	 * 大眼路
	 */
	public bigEyeRoad:string = "";
	/**
	 * 小路
	 */
	public smallRoad:string = "";
	/**
	 * 蟑螂路
	 */
	public roachRoad:string = "";
}
class BaseRoadMapItem extends BaseView implements IRoadMapItem
{
	private data:any;
	public constructor() 
	{
		super();
	}

	public setData(v:any)
	{
		if(this.data==v)return;
		this.data = v;
		this.applyData(this.data);
	}
	public getData():any
	{
		return this.data;
	}
	protected applyData(v:any):void
	{

	}
}
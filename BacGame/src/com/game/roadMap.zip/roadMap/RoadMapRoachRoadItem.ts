class RoadMapRoachRoadItem extends BaseRoadMapItem
{
	private bitmap:egret.Bitmap;
	protected applyData(v:any):void
	{
		if(v!=null)
		{
			if(this.bitmap==null)
			{
				this.bitmap = new egret.Bitmap();
				this.addChild(this.bitmap);
			}
			this.bitmap.texture = RES.getRes("roadMap_roach_road_"+v+"_png");
		}else
		{
			if(this.bitmap)this.bitmap.texture = null;
		}
	}
}
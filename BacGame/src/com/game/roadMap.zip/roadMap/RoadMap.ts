/**
 * 路纸
 */
class RoadMap extends BaseView
{
	public static A	:	string	=	"a";
	public static B	:	string	=	"b";
	public static C	:	string	=	"c";
	public static D	:	string	=	"d";
	public static E	:	string	=	"e";
	public static F	:	string	=	"f";
	public static G	:	string	=	"g";
	public static H	:	string	=	"h";
	public static I	:	string	=	"i";
	public static J	:	string	=	"j";
	public static K	:	string	=	"k";
	public static L	:	string	=	"l";
	protected data:string;
	protected drawFramer:JFramer;
	protected items:Array<BaseRoadMapItem>;
	public constructor() 
	{
		super();
		this.init();
	}
	private init()
	{
		this.drawFramer = JFramer.getFramer();
		this.drawFramer.addFramerCallback(this.onDelayDrawRoadMap,this);
		this.items = new Array<BaseRoadMapItem>();
	}

	/**设置数据 */
	public setData(value:string)
	{
		if(this.data==value)return;
		this.data = value;
		this.drawFramer.start();
	}
	/**延时绘制当前的路纸信息 */
	protected onDelayDrawRoadMap()
	{
		var roadStr:RoadStringObject = BeadRoad.createRoadReanderString(this.data);
		//this.drawMainRoad(this.data);
		//this.drawBigRoad(roadStr.bigRoad);
		//this.drawBigEyeRoad(roadStr.bigEyeRoad);
		//this.drawSmallRoad(roadStr.smallRoad);
		//this.drawRoachRoad(roadStr.roachRoad);
		this.drawFramer.stop();
	}
	/**
	 * 画主路纸,主路纸是竖向显示
	 * @columnGridNum 表示1竖显示多少个路格
	 * @maxColumn 可以显示的最大列，超出最大列部分时按规则显示
	 */
	protected drawMainRoad(roadStr:string,columnGridNum:number = 6,maxColumn:number = 11,gridWidth:number = 34,gridHeight:number = 34,offsetX:number = 2,offsetY:number = 0)
	{
		//// 规则：超过最大列时，显示长度不变，超过部分往后挪动
		var allRoads:any[] = roadStr.split(".");
		var allColumu:number = Math.ceil(allRoads.length / columnGridNum);
		var startIndex:number = 0;
		var len:number = allRoads.length;
		let i:number = 0;
		if(allColumu>maxColumn)
		{
			startIndex = (allColumu-maxColumn)*columnGridNum;
			len = allRoads.length - startIndex;
		}
		this.setRoadItems(len,RoadMapMainItem);
		for (i = 0;i<len;i++)
		{
			if(this.items[i].parent==null)this.addChild(this.items[i]);
			this.items[i].setData(allRoads[startIndex+i]);
			this.items[i].x = Math.floor(i/columnGridNum)*gridWidth+((gridWidth-this.items[i].width)*0.5+offsetX);
			this.items[i].y = Math.floor(i%columnGridNum)*gridHeight+((gridHeight-this.items[i].height)*0.5+offsetY);
		}
	}
	/**
	 * 画大路
	 */
	protected drawBigRoad(roadData:string,columnGridNum:number = 6,maxGridNum:number = 30,gridWidth:number=20,gridHeight:number=20,offsetX:number = 0,offsetY:number = 0)
	{
		var roads:any = BeadRoad.createBigRoadRenderGrid(roadData,null,columnGridNum);
		var gridRoads:any[] = roads[0];
		var tieRoads:any[] = roads[1];
		var roadLen:number = gridRoads.length;
		var startIndex:number = roadLen>maxGridNum?(roadLen-maxGridNum):0;
		var allItemLen:number = 0;
		var xData:any[];
		var tData:any[];
		var i:number = 0;
		var j:number = 0;
		var itemIndex:number = 0;
		var tieItemCount:number = 0;
		for(i = 0;i<roadLen;i++)
		{
			allItemLen+=gridRoads[i].length;
		}
		this.setRoadItems(allItemLen,RoadMapBigRoadItem);
		for(i=startIndex;i<roadLen;i++)
		{
			xData = gridRoads[i];
			tData = tieRoads[i];
			for(j=0;j<xData.length;j++)
			{
				if(xData[j]&&xData[j]!="null")
				{
					if(tData!=null&&tData[j]!=null)
					{
						tieItemCount = tData[j].length;
					}else
					{
						tieItemCount = 0;
					}
					if(this.items[itemIndex].parent==null)this.addChild(this.items[itemIndex]);
					this.items[itemIndex].setData(xData[j]+","+tieItemCount);
					this.items[itemIndex].x = gridWidth*(i-startIndex)+offsetX;
					this.items[itemIndex].y = gridHeight*j+offsetY;
					itemIndex++;
				}
			}
		}
	}
	/**
	 * 画大眼路
	 */
	protected drawBigEyeRoad(roadData:string,columnGridNum:number = 6,maxGridNum:number = 30,gridWidth:number=6,gridHeight:number=6,offsetX:number = 0,offsetY:number = 0)
	{
		this.drawGeneralSameRoad(roadData,RoadMapBigEyeRoadItem,columnGridNum,maxGridNum,gridWidth,gridHeight,offsetX,offsetY);
	}
	/**
	 * 画小路
	 */
	protected drawSmallRoad(roadData:string,columnGridNum:number = 6,maxGridNum:number = 30,gridWidth:number=6,gridHeight:number=6,offsetX:number = 0,offsetY:number = 0)
	{
		this.drawGeneralSameRoad(roadData,RoadMapSmallRoadItem,columnGridNum,maxGridNum,gridWidth,gridHeight,offsetX,offsetY);
	}
	/**
	 * 画蟑螂路
	 */
	protected drawRoachRoad(roadData:string,columnGridNum:number = 6,maxGridNum:number = 30,gridWidth:number=6,gridHeight:number=6,offsetX:number = 0,offsetY:number = 0)
	{
		this.drawGeneralSameRoad(roadData,RoadMapRoachRoadItem,columnGridNum,maxGridNum,gridWidth,gridHeight,offsetX,offsetY);
	}
	protected setRoadItems(len:number,itemClass:any)
	{
		if(this.items.length>len)
		{
			for(let i:number = len;i<this.items.length;i++)
			{
				if(this.items[i].parent)
					this.items[i].parent.removeChild(this.items[i]);
			}
		}else
		{
			while(this.items.length<len)
			{
				this.items.push(new itemClass());
			}
		}
	}
	protected drawGeneralSameRoad(roadData:string,itemClass:any,columnGridNum:number,maxGridNum:number,gridWidth:number,gridHeight:number,offsetX:number,offsetY:number)
	{
		var roads:any = BeadRoad.createRoadRenderGrid(roadData,null,columnGridNum);
		var gridRoads:any[] = roads[0];
		var roadLen:number = gridRoads.length;
		var startIndex:number = roadLen>maxGridNum?(roadLen-maxGridNum):0;
		var allItemLen:number = 0;
		var xData:any[];
		var i:number = 0;
		var j:number = 0;
		var itemIndex:number = 0;
		for(i = 0;i<roadLen;i++)
		{
			allItemLen+=gridRoads[i].length;
		}
		this.setRoadItems(allItemLen,itemClass);
		for(i = startIndex;i<roadLen;i++)
		{
			xData = gridRoads[i];
			for(j = 0;j<xData.length;j++)
			{
				if(this.items[itemIndex].parent==null)this.addChild(this.items[itemIndex]);
				this.items[itemIndex].setData(xData[j]);
				this.items[itemIndex].x = gridWidth*(i-startIndex)+offsetX;
				this.items[itemIndex].y = gridHeight*j+offsetY;
				itemIndex++;
			}
		}		
	}
	public dispose()
	{
		super.dispose();
		if(this.drawFramer!=null)
			this.drawFramer.dispose();
		this.drawFramer = null;
	}
}